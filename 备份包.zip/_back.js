// 探针：从子页面返回首页时，到达项首帧是否落在接缝坐标。临时文件。
(function () {
  var log = {};

  function dump() {
    var pre = document.createElement("pre");
    pre.id = "PROBE";
    pre.textContent = JSON.stringify(log, null, 1);
    (document.body || document.documentElement).appendChild(pre);
  }

  window.addEventListener("error", function (e) {
    log.ERROR = e.message + " @" + (e.filename || "?") + ":" + e.lineno;
    dump();
  });

  document.addEventListener("DOMContentLoaded", function () {
    log.htmlClass = document.documentElement.className;
    log.backNo = document.documentElement.getAttribute("data-back-no");
    log.splashDisplay = (function () {
      var s = document.getElementById("splash");
      return s ? getComputedStyle(s).display : "no #splash";
    })();

    // 接缝坐标（同 initBackArrive 的探针做法）
    var probe = document.createElement("div");
    probe.style.cssText =
      "position:fixed;left:var(--title-left);top:var(--title-top);width:0;height:0;visibility:hidden";
    document.body.appendChild(probe);
    var seam = probe.getBoundingClientRect();
    probe.remove();
    log.seam = [+seam.left.toFixed(2), +seam.top.toFixed(2)];

    // 首帧：到达项的 .orbit-inner 应当被顶到接缝
    requestAnimationFrame(function () {
      var arriving = document.querySelector(".orbit-item.is-arriving");
      log.arrivingFound = !!arriving;
      if (arriving) {
        log.arrivingPos = arriving.className.match(/pos-\d/)[0];
        var inner = arriving.querySelector(".orbit-inner");
        var r = inner.getBoundingClientRect();
        log.firstFrameInner = [+r.left.toFixed(2), +r.top.toFixed(2)];
        log.inlineTransform = inner.style.transform || "(空)";
        log.deltaFromSeam = [
          +(r.left - seam.left).toFixed(2),
          +(r.top - seam.top).toFixed(2)
        ];
        log.textAlign = getComputedStyle(inner).textAlign;
        log.lineShifts = [].map.call(inner.children, function (el) {
          return el.style.getPropertyValue("--sx") || "(未设)";
        });
        log.innerOpacity = getComputedStyle(inner).opacity;
      }
      // 其余五项应当仍不可见
      log.othersOpacity = [].map.call(
        document.querySelectorAll(".orbit-item:not(.is-arriving) .orbit-inner"),
        function (el) { return getComputedStyle(el).opacity; }
      );
      log.ringOffset = (function () {
        var p = document.querySelector(".orbit-ring-path");
        return p ? getComputedStyle(p).strokeDashoffset : "n/a";
      })();
      log.bodyClass = document.body.className;

      // 落地后：摘类、text-align 复原、位置回到轨道
      setTimeout(function () {
        var el = document.querySelector('[data-no="' + log.backNo + '"]');
        if (el) {
          var inner2 = el.querySelector(".orbit-inner");
          var r2 = inner2.getBoundingClientRect();
          log.afterLandInner = [+r2.left.toFixed(2), +r2.top.toFixed(2)];
          log.afterLandAlign = getComputedStyle(inner2).textAlign;
          log.stillArriving = el.classList.contains("is-arriving");
          log.afterLandShifts = [].map.call(inner2.children, function (e2) {
            return e2.style.getPropertyValue("--sx") || "(已清)";
          });
        }
        log.bodyClassLater = document.body.className;
        dump();
      }, 900);
    });
  });
})();
