// 探针：在 invert 就位那一帧量（等 html.back-ready 出现）。临时文件。
(function () {
  var log = {}, tries = 0;
  function seamPt() {
    var p=document.createElement("div");
    p.style.cssText="position:fixed;left:var(--title-left);top:var(--title-top);width:0;height:0;visibility:hidden";
    document.body.appendChild(p); var r=p.getBoundingClientRect(); p.remove();
    return r;
  }
  function dump(id){var pre=document.createElement("pre");pre.id=id;pre.textContent=JSON.stringify(log,null,1);document.body.appendChild(pre);}
  function watch() {
    var root=document.documentElement;
    tries++;
    if (root.classList.contains("back-ready") && !root.classList.contains("back-play")) {
      var seam=seamPt();
      var a=document.querySelector(".orbit-item.is-arriving");
      var inner=a.querySelector(".orbit-inner");
      var r=inner.getBoundingClientRect();
      log.frames=tries;
      log.seam=[+seam.left.toFixed(2),+seam.top.toFixed(2)];
      log.invertedInner=[+r.left.toFixed(2),+r.top.toFixed(2)];
      log.deltaFromSeam=[+(r.left-seam.left).toFixed(2),+(r.top-seam.top).toFixed(2)];
      log.pos=a.className.match(/pos-\d/)[0];
      log.opacity=getComputedStyle(inner).opacity;
      log.textAlign=getComputedStyle(inner).textAlign;
      log.lineLefts=[].map.call(inner.children,function(e){return +e.getBoundingClientRect().left.toFixed(2);});
      log.shifts=[].map.call(inner.children,function(e){return e.style.getPropertyValue("--sx");});
      // 再等落地后量一次
      setTimeout(function(){
        var el=document.querySelector('[data-no="'+document.documentElement.getAttribute("data-back-no")+'"]');
        var i2=el.querySelector(".orbit-inner"); var r2=i2.getBoundingClientRect();
        log.afterLand=[+r2.left.toFixed(2),+r2.top.toFixed(2)];
        log.afterAlign=getComputedStyle(i2).textAlign;
        log.afterShifts=[].map.call(i2.children,function(e){return e.style.getPropertyValue("--sx")||"(已清)";});
        log.afterLineLefts=[].map.call(i2.children,function(e){return +e.getBoundingClientRect().left.toFixed(2);});
        log.stillArriving=el.classList.contains("is-arriving");
        dump("PROBE2");
      },900);
      return;
    }
    if (tries<200) requestAnimationFrame(watch);
    else { log.timeout=true; log.htmlClass=root.className; dump("PROBE2"); }
  }
  document.addEventListener("DOMContentLoaded", function(){ requestAnimationFrame(watch); });
})();
