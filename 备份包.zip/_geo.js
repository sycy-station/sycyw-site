// 探针：量 pos-1 / pos-5 在「轨道静止态」与「飞行态」下，每行文字的真实左缘。
// 用 Range 量文字本身，不是被 stretch 的网格项盒子。临时文件。
(function () {
  function textRect(el) {
    var r = document.createRange();
    r.selectNodeContents(el);
    var b = r.getBoundingClientRect();
    r.detach && r.detach();
    return b;
  }
  function snap(item) {
    var inner = item.querySelector(".orbit-inner");
    var ib = inner.getBoundingClientRect();
    return {
      innerBox: [+ib.left.toFixed(2), +ib.top.toFixed(2), +ib.width.toFixed(2)],
      lines: [].map.call(inner.children, function (el) {
        var box = el.getBoundingClientRect();
        var tx = textRect(el);
        return {
          cls: el.className,
          boxLeft: +box.left.toFixed(2),
          boxW: +box.width.toFixed(2),
          textLeft: +tx.left.toFixed(2),
          textW: +tx.width.toFixed(2)
        };
      })
    };
  }
  window.addEventListener("load", function () {
    window.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape" }));
    setTimeout(function () {
      var out = {};
      ["pos-1", "pos-5"].forEach(function (p) {
        var item = document.querySelector(".orbit-item." + p);
        out[p] = { rest: snap(item) };
        // 飞行态：加 nav-back + is-arriving，看 text-align:left 后文字去哪
        document.documentElement.classList.add("nav-back", "back-ready");
        item.classList.add("is-arriving");
        void item.getBoundingClientRect();
        out[p].flight = snap(item);
        item.classList.remove("is-arriving");
        document.documentElement.classList.remove("nav-back", "back-ready");
        void item.getBoundingClientRect();
      });
      // 子页标题块的等价结构（用于对比接缝该对到哪）
      var pre = document.createElement("pre");
      pre.id = "GEO";
      pre.textContent = JSON.stringify(out, null, 1);
      document.body.appendChild(pre);
    }, 2500);
  });
})();
